#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int next_permutation(int *first, int *last);

// Función para calcular la distancia total de una ruta
int calcular_distancia_total(int ruta[], int **distancias, int N) {
    int distancia_total = 0;
    for (int i = 0; i < N - 1; i++) {
        distancia_total += distancias[ruta[i]][ruta[i + 1]];
    }
    distancia_total += distancias[ruta[N - 1]][ruta[0]];  // Volver al punto de partida
    return distancia_total;
}

// Función para generar permutaciones y encontrar la mejor ruta
void tsp_fuerza_bruta(int **distancias, int N, int *mejor_ruta, int *mejor_distancia) {
    int *ciudades = malloc(N * sizeof(int));
    for (int i = 0; i < N; i++) {
        ciudades[i] = i;
    }

    *mejor_distancia = INT_MAX;
    
    do {
        int distancia_actual = calcular_distancia_total(ciudades, distancias, N);
        if (distancia_actual < *mejor_distancia) {
            *mejor_distancia = distancia_actual;
            for (int i = 0; i < N; i++) {
                mejor_ruta[i] = ciudades[i];
            }
        }
    } while (next_permutation(ciudades, ciudades + N));

    // Añadir el nodo inicial al final de la ruta para cerrar el ciclo
    mejor_ruta[N] = mejor_ruta[0];

    free(ciudades);
}

// Función para generar la siguiente permutación lexicográfica
int next_permutation(int *first, int *last) {
    if (first == last) return 0;
    int *i = last - 1;
    while (i > first && *(i - 1) >= *i) --i;
    if (i == first) return 0;
    int *j = last;
    while (*(--j) <= *(i - 1));
    int temp = *(i - 1);
    *(i - 1) = *j;
    *j = temp;
    for (j = last - 1; i < j; ++i, --j) {
        temp = *i;
        *i = *j;
        *j = temp;
    }
    return 1;
}

int main() {
    int N;
    printf("Ingrese el tamaño de la matriz (N): ");
    scanf("%d", &N);

    // Generar la matriz de distancias aleatorias y mostrarla en la consola
    printf("Matriz de distancias generada aleatoriamente:\n");
    int **distancias = malloc(N * sizeof(int *));
    for (int i = 0; i < N; i++) {
        distancias[i] = malloc(N * sizeof(int));
        for (int j = 0; j < N; j++) {
            if (i == j) {
                distancias[i][j] = 0;
            } else {
                distancias[i][j] = rand() % 100 + 1;  // Valores aleatorios entre 1 y 100
            }
            printf("%4d ", distancias[i][j]);  // Imprimir cada elemento de la matriz
        }
        printf("\n");
    }

    // Resolver el TSP usando fuerza bruta
    int *mejor_ruta = malloc((N + 1) * sizeof(int));  // Nodos de la ruta más el nodo inicial al final
    int mejor_distancia;
    
    clock_t start_time = clock();
    tsp_fuerza_bruta(distancias, N, mejor_ruta, &mejor_distancia);
    clock_t end_time = clock();

    // Imprimir resultados en la consola
    printf("\nMejor ruta: ");
    for (int i = 0; i <= N; i++) {
        printf("%d, ", mejor_ruta[i]);
    }
    printf("\nMejor distancia: %d\n", mejor_distancia);
    printf("Tiempo de ejecución: %.4f segundos\n", (double)(end_time - start_time) / CLOCKS_PER_SEC);

    // Generar archivo DOT para el grafo
    FILE *grafoArchivo;
    grafoArchivo = fopen("grafo_tsp.dot", "w");
    if (grafoArchivo == NULL) {
        printf("Error al abrir el archivo para el grafo.\n");
        return 1;
    }
    fprintf(grafoArchivo, "graph TSP {\n");

    // Escribir aristas del grafo
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            fprintf(grafoArchivo, "%d -- %d [label=\"%d\"];\n", i, j, distancias[i][j]);
        }
    }

    // Escribir la mejor ruta resaltada en rojo
    for (int i = 0; i < N; i++) {
        fprintf(grafoArchivo, "%d -- %d [color=red];\n", mejor_ruta[i], mejor_ruta[i+1]);
    }

    fprintf(grafoArchivo, "}\n");
    fclose(grafoArchivo);

    printf("Archivo DOT del grafo generado como 'grafo_tsp.dot'.\n");

    // Liberar memoria y otros procesamientos
    for (int i = 0; i < N; i++) {
        free(distancias[i]);
    }
    free(distancias);
    free(mejor_ruta);

    return 0;
}
