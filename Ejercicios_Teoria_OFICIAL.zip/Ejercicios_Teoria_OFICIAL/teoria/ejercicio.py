import itertools
import time
import random
import networkx as nx
import matplotlib.pyplot as plt

# Función para calcular la distancia total de una ruta
def calcular_distancia_total(ruta, distancias):
    distancia_total = 0
    for i in range(len(ruta) - 1):
        distancia_total += distancias[ruta[i]][ruta[i + 1]]
    distancia_total += distancias[ruta[-1]][ruta[0]]  # Volver al punto de partida
    return distancia_total

# Función para resolver el TSP usando fuerza bruta
def tsp_fuerza_bruta(distancias):
    N = len(distancias)
    ciudades = list(range(N))
    mejor_ruta = None
    mejor_distancia = float('inf')
    
    for ruta in itertools.permutations(ciudades):
        distancia = calcular_distancia_total(ruta, distancias)
        if distancia < mejor_distancia:
            mejor_distancia = distancia
            mejor_ruta = ruta + (ruta[0],)  # Agregar el retorno al punto de partida
    
    return mejor_ruta, mejor_distancia

# Solicitar al usuario el tamaño de la matriz
N = int(input("Ingrese el tamaño de la matriz (N): "))

# Generar la matriz de distancias aleatoriamente
distancias = [[random.randint(1, 100) if i != j else 0 for j in range(N)] for i in range(N)]

print("Matriz de distancias generada aleatoriamente:")
for fila in distancias:
    print(fila)

# Medir el tiempo de ejecución
start_time = time.time()
mejor_ruta, mejor_distancia = tsp_fuerza_bruta(distancias)
end_time = time.time()

print("Mejor ruta:", mejor_ruta)
print("Mejor distancia:", mejor_distancia)
print("Tiempo de ejecución: {:.5f} segundos".format(end_time - start_time))

# Dibujar el grafo
G = nx.Graph()

for i in range(len(distancias)):
    for j in range(i + 1, len(distancias)):
        if distancias[i][j] != 0:  # Agregar solo bordes que existan en la matriz de distancias
            G.add_edge(i, j, weight=distancias[i][j])

pos = nx.spring_layout(G)
nx.draw(G, pos, with_labels=True, node_color='lightblue', node_size=500, font_size=10)
edge_labels = nx.get_edge_attributes(G, 'weight')
nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)

path_edges = [(mejor_ruta[i], mejor_ruta[i+1]) for i in range(len(mejor_ruta) - 1)]
path_edges.append((mejor_ruta[-1], mejor_ruta[0]))  # Agregar el enlace de retorno al punto de partida
nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color='r', width=2)

# Agregar leyenda con líneas negras y rojas
plt.text(0.1, 0.1, "━━━ Ruta encontrada", fontsize=10, transform=plt.gcf().transFigure, color='black')
plt.text(0.1, 0.05, "━━━ Ruta óptima", fontsize=10, transform=plt.gcf().transFigure, color='red')

plt.show()
